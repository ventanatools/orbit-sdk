Start the companion yourself, then choose Save connection info in the host.
